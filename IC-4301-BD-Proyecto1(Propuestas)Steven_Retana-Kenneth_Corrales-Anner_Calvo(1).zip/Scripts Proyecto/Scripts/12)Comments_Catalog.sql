--INSERT COMMENTS IN PROPOSAL--
INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Es una muy buena idea me parece que est� bien implementada la propuesta que se quiere llevar a cabo sin embargo hay que tener cuidado de que los due�os de las mascotas realmente se hagan responsables por los desechos de sus animales y no los dejen tirados en el camino porque esto puede afectar a otras personas.', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(2, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '701548756');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Me gusta la idea sin embargo hay que tener cuidado porque en estos d�as hay mucho vandalismo no nos gustar�a que despu�s de hacer un esfuerzo para poder llevar a cabo este proyecto llegue alguien a da�ar o a probar alguna c�mara entonces me gustar�a que teniendo un poco m�s de dinero se puede hacer una forma de resguardar las c�maras para evitar cualquier da�o.', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(3, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108566974');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Es un gran proyecto que se quiere llevar a cabo que las personas j�venes tienen el derecho de poder expresarse y mostrarle al mundo las capacidades que tienen y qu� mejor forma de hacerlo que mediante el deporte de esta forma se evita caer en problemas con drogas o ese tipo de situaciones pudiendo llevar al pa�s a un mejor futuro', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(4, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '106760070');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Me gusta la idea sin embargo quiero que tengan presente que el presupuesto para poder llevar a cabo un proyecto como �ste es muy alto y tal vez no logramos alcanzar lo La idea es proyectar un plan para poder llevarlo a cabo poco a poco y no sabemos a intentar resolver todos los problemas al momento porque eso afectar�a m�s la situaci�n en la que estamos', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(11, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '602547884');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Yo pienso que todas las personas quieren tener su propio negocio para poder seguir adelante sin embargo no todos los negocios son factibles hay que elegir bien A qu� negocio se va a apoyar y a cu�l no. porque lo que se busca es una mejora del pa�s y si se invierte dinero en un negocio que no va a funcionar Ser�a m�s bien contraproducente para el proyecto que queremos llevar a cabo', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(22, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '102163589');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'El turismo en nuestro pa�s es la principal fuente de ingreso en las costas y en los hoteles alrededor del pa�s que paga sus impuestos no estar�a mal apoyarlos de alguna forma para poder incrementar la visibilidad de nuestro pa�s en el extranjero haciendo que m�s personas est�n interesadas y puedan venir a vacacionar a nuestro pa�s', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(23, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '516587945');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Est� bien que los j�venes tengan un lugar donde puedan reunirse e intercambiar sus conocimientos o sus habilidades y mostr�rselas a las dem�s sin embargo llevar a cabo un proyecto como �ste que tiene un presupuesto tan alto es un poco riesgoso. Esto debido a que estos centros pueden ser usados de una diferente manera en la que estamos pensando poner censados por el para contactar con otras personas y usar estos centros como una forma de centro intermediario para llevar a cabo tales acciones il�citas.', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(9, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108566974');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Nuestro pa�s siempre se ha caracterizado por invertir m�s en la educaci�n de las armas por eso Estoy totalmente de acuerdo con que este proyecto se lleve a cabo buscando que m�s personas j�venes puedan terminar el colegio y salir adelante haciendo que nuestro pa�s puede avanzar a un mejor futuro y de una mejor forma', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(24, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '185472536');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Me parece muy bien que se lleve a cabo un proyecto como �ste muchas personas no tienen conciencia de lo que hacen cuando tiran su basura el m�s estar�a de acuerdo Incluso en el que se pusiera una multa a las personas que cometen este tipo de acciones ya que realmente no est�n pensando en la comunidad s�lo est�n pensando que tener que deshacerse de su basura simplemente', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(6, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108450931');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'La expansi�n de la construcci�n urbana est� afectando en sobremanera las zonas Rurales que tenemos hoy en d�a reduciendo el �rea verde con el que cuenta el pa�s me parece bien que haya un control sobre este tipo de construcciones para que podamos seguir siendo el pa�s verde que siempre hemos sido', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(7, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '119672845');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Hay muchas personas en las comunidades que no s�lo en esta est�n expuestos a riesgos sociales y estas personas pueden ser ayudados de alguna forma nosotros podemos apoyarnos haciendo ayer en eso intentando compartir con ellas los conocimientos que tenemos sobre c�mo puedes llevar a cabo proyectos de avances social, por eso  apoyo el proyecto totalmente', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(14, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108891423');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'No me gusta este proyecto es un presupuesto muy alto que podr�amos usar para otro tipo de cosas m�s importantes no entiendo por qu� le dan tanta prioridad de este tipo de cosas cuando hay cosas m�s preocupantes ocurriendo en la sociedad d�a a d�a', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(11, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '516587945');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Este proyecto me agrada me parece muy bien que los j�venes tengan un lugar donde poder ir a trabajar o es desarrollar sus habilidades cuando termine el colegio o de alguna forma est�n desempleados sin embargo pienso que este proyecto puede ir m�s all� y no s�lo para las personas j�venes sino que tambi�n para personas adultas que tienen problemas de trabajo en el momento', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(18, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108566974');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Nadie tiene por qu� ser maltratado por pensar obesa diferente y a pesar de que pienso que estos educaci�n que se da desde la casa no est� mal reforzar este tipo de actitudes en las instituciones haciendo ver a los ni�os que toda persona diferente y que no por eso tiene que ser tratado de diferente manera', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(20, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108566974');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Hacer deporte es una forma de decir quitarse el peso del d�a y eso no s�lo para las personas j�venes en las personas adultas tambi�n y ni�os que simplemente Quiero jugar por eso apoyo la propuesta totalmente sin embargo quiero que se tenga en cuenta que no tenemos un presupuesto para cubrir todas las necesidades de que un proyecto As� que quiera llevarse a cabo', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(13, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '117060279');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Se debe de estudiar no solo desde el �mbito biol�gico, no solo los procesos que suceden los cambios hormonales, sino tambi�n desde el  �rea socio-afectiva', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(16, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '117060279');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Todas las personas tiene que saber los derechos que se tiene por ser persona y hasta d�nde llegan estos derechos para no invadir a los de los dem�s y no entran en conflicto tanto personales como legales con estas personas y est� bueno que se ense�e desde peque�o a las personas a comprender este tipo de temas que cuando llegan a ser adultos y no tiene ninguna base puede ser m�s complicado comprender', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(19, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108450931');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Es importante ya que es un problema que est� causando muchas deserciones en las escuelas, ser� de mucho bienestar para la sociedad y la comunidad educativa si se imparte la educaci�n sexual como materia en las escuelas.La educaci�n sexual, incluyendo sus aspectos espirituales, debe ser parte de una amplia en salud y moral, desde k�nder Garden hasta el doceavo grado, idealmente llevada a cabo armoniosamente por padres y maestros.', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(16, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '106760070');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Estar en riesgo de pobreza y exclusi�n social influye negativamente en el estado de salud, algo que se refleja en la mayor incidencia de enfermedades graves y cr�nicas. Tambi�n incide en las dificultades econ�micas para la atenci�n de la propia salud. De hecho, el 35.1% ha tenido dificultades econ�micas para cubrir gastos relacionados con su salud en el �ltimo a�o. En este sentido, las dificultades m�s frecuentes son los problemas para pagar medicinas, por eso este proyecto es tan importante', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(14, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '144785623');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Mejora la seguridad de las personas que por ah� pasen ya que al tener c�mara se puede reducir el vandalismo y la delincuencia.', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(3, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '144785623');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'La escuela debe ense�arles a los ni�os y estudiantes en general el a,b,c y el 1,2,3 cosas as�, es decir cosas �tiles para sus vidas para que puedan defenderse en la vida y elegir una profesi�n u oficio que les permita ganarse el sustento, ese es el fin �ltimo de la educaci�n, lo dem�s son cosas superfluas. Aparte �por qu� el estado debe ser quien monopolice la educaci�n?', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(21, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '117060279');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'El reconocimiento y la aceptaci�n de algo tan troncal como la identidad sexual y la propia orientaci�n sexual son el a, b, c, de cosas �tiles para la vida. Y conocer los mecanismos para la defensa de sus derechos es el 1, 2, 3, para defenderse en la vida. Ninguno de estos asuntos son cosas superfluas. En cuanto a la monopolizaci�n de la educaci�n por parte del Estado: no hay tal. La prueba es la proliferaci�n de instituciones educativas privadas en todos los niveles del sistema educativo. Lo que s� hay es un monopolio de vigilancia y control del servicio p�blico de educaci�n, aunque lo presten entidades privadas. Esto es propio de la potestad de todo Estado.', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(21, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '119672845');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Es una buena manera de que las personas se integren a otros grupos y no est�n sumidos en su propio mundo que busque ayuda y compartir con dem�s personas que sea necesario para poder crecer integralmente', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(15, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '117060279');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Las calles de esta comunidad es aut�ntico desastre hay que hacer para regular el tr�nsito y todo el medio que se muere en las calles esto debido a que muchos ni�os que se mueven en las calles que van para sus escuelas y personas mayores que pueden estar en riesgo de un atropello o una mala situaci�n y no s�lo est�s tan j�venes y adultos que se dirigen hacia sus trabajos', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(8, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '206745284');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Buscar apoyar a los j�venes deben ser una prioridad es para cualquier gobierno y una de las mejores formas de hacerlo es promoviendo el deporte donde ellos se pueden desempe�ar y mostrar las habilidades que tienen por eso apoyar proyectos que tengan esa finalidad siempre va a ser una ganancia para el pa�s y para las comunidades en donde se lleve a cabo', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(4, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108450931');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'No puede ser posible que cualquier persona pueda construir donde pr�cticamente quiera sin pensar en los riesgos ambientales y econ�micos que pueden ocasionar no s�lo a la comunidad sino incluso a ellos mismos sino se plantea bien la situaci�n en la que se quiere construir', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(7, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '117060279');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Las personas no pueden construir donde quieran necesitan el permiso para poder hacer cualquier tipo de construcci�n ya sea en sus casas o en un terreno no pueden hacerlo por deseo propio tiene que tener un respaldo de una instituci�n que asegure que puede llevarse a cabo cualquier tipo de construcci�n, reparaci�n o mantenimiento', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(7, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '108450931');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'La cultura y la historia el que nos forja como naci�n y preservar estas estructuras como patrimonios de nuestra comunidad es de suma importancia para mostrarle al mundo que somos un pa�s con identidad propia y que no necesita copiarse de nadie m�s', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(11, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '701548756');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Se debe intentar ayudar a las personas que quieren crear su propia empresa que tienen un plan definido y que sabe c�mo llevar a cabo estas personas son las que podr�an hacer que nuestro pa�s hay adelante ya que diversificar y en la econom�a y no nos vamos a estancar en s�lo un tipo de producto a ofrecer al mundo', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(22, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '102163589');

INSERT INTO PROPOSAL_COMMENT (ID_COMMENT,COMMENT_DESCRIPTION,COMMENT_DATE)
VALUES(S_COMMENT.NEXTVAL, 'Da la posibilidad de nuevos empleos, sin embargo tambi�n puede traer repercusiones negativas como el aumento de la cantidad de bares, casinos y prost�bulos. Se requiere una gran cooperaci�n del sector tur�stico con el estado para que una econom�a basada en el turismo de frutos', SYSDATE);
INSERT INTO PROPOSAL_X_COMMENT(ID_PROPOSAL,ID_COMMENT) VALUES(23, s_comment.currval);
INSERT INTO PERSON_X_COMMENT(ID_COMMENT, ID_PERSON) VALUES(s_comment.currval, '516587945');

