--------CREACION DE PERSONAS USUARIAS DEL SISTEMA-----------
insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('117060279','Steven','Retana','Cede�o',To_Date('09/04/1998','DD,MM,YYYY'),85);
insert into email(email,identification) values ('stevenretana98@gmail.com','117060279');
insert into telephone (telephone,identification) values ('88260185','117060279');
insert into telephone (telephone,identification) values ('22359744','117060279');
insert into nationality_x_person(id_nationality,id_person) values (5,'117060279');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('106760070','Mayela','Cede�o','Mora',To_Date('07/05/1963','DD,MM,YYYY'),85);
insert into email(email,identification) values ('mayecedeno@yahoo.com','106760070');
insert into telephone (telephone,identification) values ('83679661','106760070');
insert into nationality_x_person(id_nationality,id_person) values (5,'106760070');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('206745284','Carlos','Zamora','Mar�n',To_Date('25/01/1973','DD,MM,YYYY'),149);
insert into email(email,identification) values ('carloszamomarin@gmail.com','206745284');
insert into telephone (telephone,identification) values ('88541278','206745284');
insert into nationality_x_person(id_nationality,id_person) values (5,'206745284');
insert into nationality_x_person(id_nationality,id_person) values (4,'206745284');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('102563985','Ang�lica','Ram�rez','P�rez',To_Date('24/08/1980','DD,MM,YYYY'),75);
insert into email(email,identification) values ('angelica_ramirez80@hotmail.com','102563985');
insert into telephone (telephone,identification) values ('89965224','102563985');
insert into nationality_x_person(id_nationality,id_person) values (5,'102563985');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('136690451','Mario','Brenes','Mart�nez',To_Date('15/04/1965','DD,MM,YYYY'),245);
insert into email(email,identification) values ('mariobrenes_1565@gmail.com','136690451');
insert into telephone (telephone,identification) values ('84457584','136690451');
insert into nationality_x_person(id_nationality,id_person) values (5,'136690451');
insert into nationality_x_person(id_nationality,id_person) values (9,'136690451');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('701548756','Kenneth','Bogantes','C�spedes',To_Date('02/11/1999','DD,MM,YYYY'),481);
insert into email(email,identification) values ('kennethboga99@gmail.com','701548756');
insert into telephone (telephone,identification) values ('87745221','701548756');
insert into nationality_x_person(id_nationality,id_person) values (5,'701548756');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('602547884','Angie','Vargas','Zamora',To_Date('28/03/2000','DD,MM,YYYY'),406);
insert into email(email,identification) values ('angie.vargasz@gmail.com','602547884');
insert into telephone (telephone,identification) values ('87441256','602547884');
insert into nationality_x_person(id_nationality,id_person) values (5,'602547884');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('108450931','Minor','Retana','Mora',To_Date('21/02/1973','DD,MM,YYYY'),85);
insert into email(email,identification) values ('mrasesoria@gmail.com','108450931');
insert into telephone (telephone,identification) values ('88268248','108450931');
insert into nationality_x_person(id_nationality,id_person) values (5,'108450931');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('108566974','Maritza','Cede�o','Mora',To_Date('24/09/1961','DD,MM,YYYY'),90);
insert into email(email,identification) values ('maritzacedeno_1961@hotmail.com','108566974');
insert into telephone (telephone,identification) values ('88584112','108566974');
insert into nationality_x_person(id_nationality,id_person) values (5,'108566974');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('185472536','Cheyenne','Sandoval','Valverde',To_Date('16/09/1999','DD,MM,YYYY'),17);
insert into email(email,identification) values ('cheyesandov@gmail.com','185472536');
insert into telephone (telephone,identification) values ('84522369','185472536');
insert into nationality_x_person(id_nationality,id_person) values (5,'185472536');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('516587945','Bernardo','Arce','Villalobos',To_Date('10/12/1965','DD,MM,YYYY'),359);
insert into email(email,identification) values ('bernardoarcevilla@hotmail.com','516587945');
insert into telephone (telephone,identification) values ('89964571','516587945');
insert into nationality_x_person(id_nationality,id_person) values (5,'516587945');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('404542658','Karina','Brenes','Torres',To_Date('19/01/1997','DD,MM,YYYY'),313);
insert into email(email,identification) values ('karina.brenes97@gmail.com','404542658');
insert into telephone (telephone,identification) values ('84573666','404542658');
insert into nationality_x_person(id_nationality,id_person) values (5,'404542658');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('119672845','Fabi�n','Retana','Cede�o',To_Date('19/04/1999','DD,MM,YYYY'),85);
insert into email(email,identification) values ('fabiretanacede@gmail.com','119672845');
insert into telephone (telephone,identification) values ('84006235','119672845');
insert into nationality_x_person(id_nationality,id_person) values (5,'119672845');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('102163589','Bryan','Cede�o','Mar�n',To_Date('01/05/1996','DD,MM,YYYY'),87);
insert into email(email,identification) values ('bryancede96@gmail.com.com','102163589');
insert into telephone (telephone,identification) values ('85983919','102163589');
insert into nationality_x_person(id_nationality,id_person) values (5,'102163589');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('105122554','Tatiana','Laguna','Lorente',To_Date('20/01/1999','DD,MM,YYYY'),88);
insert into email(email,identification) values ('tati.laguna@yahoo.com','105122554');
insert into telephone (telephone,identification) values ('88956421','105122554');
insert into nationality_x_person(id_nationality,id_person) values (5,'105122554');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('108891423','Ginnete','Solano','Cede�o',To_Date('28/10/91','DD,MM,YYYY'),90);
insert into email(email,identification) values ('ginnetesol91@gmail.com','108891423');
insert into telephone (telephone,identification) values ('87455120','108891423');
insert into nationality_x_person(id_nationality,id_person) values (5,'108891423');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('503216457','Luis','Zeled�n','Trejos',To_Date('19/07/1980','DD,MM,YYYY'),347);
insert into email(email,identification) values ('zeledon.trejos.luis@yahoo.com','503216457');
insert into telephone (telephone,identification) values ('87415246','503216457');
insert into nationality_x_person(id_nationality,id_person) values (5,'503216457');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('169952549','Silvia','Calder�n','Cede�o',To_Date('19/09/1983','DD,MM,YYYY'),83);
insert into email(email,identification) values ('silviacalce@gmail.com','169952549');
insert into telephone (telephone,identification) values ('88423667','169952549');
insert into nationality_x_person(id_nationality,id_person) values (5,'169952549');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('105847965','Angie','Rocha','Retana',To_Date('18/02/1994','DD,MM,YYYY'),17);
insert into email(email,identification) values ('angierore1994@hotmail.com','105847965');
insert into telephone (telephone,identification) values ('84551274','105847965');
insert into nationality_x_person(id_nationality,id_person) values (5,'105847965');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('248579815','Francisco','Araya','Sol�s',To_Date('24/06/1975','DD,MM,YYYY'),157);
insert into email(email,identification) values ('francisco.araya.solis@yahoo.com','248579815');
insert into telephone (telephone,identification) values ('85741234','248579815');
insert into nationality_x_person(id_nationality,id_person) values (5,'248579815');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('144785623','Stephanie','Solano','Cede�o',To_Date('21/10/1996','DD,MM,YYYY'),90);
insert into email(email,identification) values ('stephsol96@gmail.com','144785623');
insert into telephone (telephone,identification) values ('89974554','144785623');
insert into nationality_x_person(id_nationality,id_person) values (5,'144785623');

insert into person(identification,name,first_last_name,second_last_name,birthdate,id_community) 
values ('120003000','Javier','Valverde','Solano',To_Date('13/09/1985','DD,MM,YYYY'),85);
insert into email(email,identification) values ('javiervalverde@gmail.com','120003000');
insert into telephone (telephone,identification) values ('82346923','120003000');
insert into nationality_x_person(id_nationality,id_person) values (5,'120003000');

commit;

------------CREACION DE LOS USUARIOS----------

insert into username(username,password,identification,id_usertype)
values ('steven','GfwACG4v3k0WQRIcOlYcDw==','117060279',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('mayela','pWJ/ugHSLCltnRvi9gz/7Q==','106760070',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('carlos','1oM08NMHkyo9/VbLHe0jTw==','206745284',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('angelica','D6RRw9+P+taLYzwLeFBRXg==','102563985',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('mario','WqvY1juPNWQ7iP5ibji4xQ==','136690451',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('kenneth','5WzTIw75O3P0nBqVTVMvcw==','701548756',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('angie9321','z2L0Od+9mTSYBV+cmAgwfg=','602547884',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('minor','RI9jTPNJmaY6qeI0EmDuTg====','108450931',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('maritza','h9xcmaMFDKqmCikjH84J3g==','108566974',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('cheyenne','GfwACG4v3k0WQRIcOlYcDw==','185472536',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('bernardo','33XcZII42vJsCtcFKZ98CA==','516587945',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('karina','7GdIDMZ9fC1Keygz1E+9og==','404542658',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('fabian','jb1JtenJj6XuFqLnztmWOw==','119672845',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('bryan','vU+uOW53ZixMr6Ltak38Hw==','102163589',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('tatiana','ogw195u0LL5Ptv9lw4R2YQ==','105122554',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('ginnete','ughbTuwX4AGKlaKIscZfFA==','108891423',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('luis22','mzli4f2aiMhheRGLzml28A==','503216457',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('silvia','QBU9yffO7zrpu4Sus1xdFA==','169952549',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('angie93','HIeP7vs8LdU2NhIZ20LWlQ==','105847965',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('francisco76','e4/f48c8B5A9Wwa+YaORQA==','248579815',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('stephanie','PCINv3vHRmkCovp9BOJokw==','144785623',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('admin','+0zLULdteNu7ozS/sE9yJw==','120003000',0);
commit;

--select proposal.id_proposal,title,proposal_description,budget,proposal_x_category.id_category from proposal inner join proposal_x_category on proposal.id_proposal=proposal_x_category.id_proposal inner join person_x_proposal 
--on proposal.id_proposal=person_x_proposal.id_proposal ;
--commit;

