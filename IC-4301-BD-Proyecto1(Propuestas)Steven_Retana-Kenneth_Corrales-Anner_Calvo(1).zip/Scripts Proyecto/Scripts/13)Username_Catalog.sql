
------------CREACION DE LOS USUARIOS----------

insert into username(username,password,identification,id_usertype)
values ('steven','GfwACG4v3k0WQRIcOlYcDw==','117060279',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('mayela','pWJ/ugHSLCltnRvi9gz/7Q==','106760070',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('carlos','1oM08NMHkyo9/VbLHe0jTw==','206745284',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('angelica','D6RRw9+P+taLYzwLeFBRXg==','102563985',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('mario','WqvY1juPNWQ7iP5ibji4xQ==','136690451',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('kenneth','5WzTIw75O3P0nBqVTVMvcw==','701548756',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('angie9321','z2L0Od+9mTSYBV+cmAgwfg=','602547884',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('minor','RI9jTPNJmaY6qeI0EmDuTg====','108450931',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('maritza','h9xcmaMFDKqmCikjH84J3g==','108566974',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('cheyenne','GfwACG4v3k0WQRIcOlYcDw==','185472536',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('bernardo','33XcZII42vJsCtcFKZ98CA==','516587945',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('karina','7GdIDMZ9fC1Keygz1E+9og==','404542658',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('fabian','jb1JtenJj6XuFqLnztmWOw==','119672845',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('bryan','vU+uOW53ZixMr6Ltak38Hw==','102163589',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('tatiana','ogw195u0LL5Ptv9lw4R2YQ==','105122554',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('ginnete','ughbTuwX4AGKlaKIscZfFA==','108891423',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('luis22','mzli4f2aiMhheRGLzml28A==','503216457',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('silvia','QBU9yffO7zrpu4Sus1xdFA==','169952549',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('angie93','HIeP7vs8LdU2NhIZ20LWlQ==','105847965',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('francisco76','e4/f48c8B5A9Wwa+YaORQA==','248579815',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('stephanie','PCINv3vHRmkCovp9BOJokw==','144785623',1);
select * from person;

insert into username(username,password,identification,id_usertype)
values ('admin','+0zLULdteNu7ozS/sE9yJw==','120003000',0);
commit;
