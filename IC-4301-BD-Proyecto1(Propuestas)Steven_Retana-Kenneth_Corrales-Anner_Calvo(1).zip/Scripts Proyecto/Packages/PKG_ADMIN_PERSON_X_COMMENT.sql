CREATE OR REPLACE PACKAGE PKG_ADMIN_PERSON_X_COMMENT  IS
       --FUNCTION GET_ID_PERSON(PNID_COMMENT IN NUMBER)  RETURN VARCHAR2;
       --FUNCTION GET_ID_COMMENT(PNID_PERSON IN NUMBER)  RETURN NUMBER;
       PROCEDURE INSERT_PERSON_X_COMMENT(PNID_PERSON VARCHAR2,PNID_COMMENT NUMBER);
       --PROCEDURE SET_ID_PERSON(NEW_VALUE NUMBER, OLD_VALUE NUMBER);
       --PROCEDURE SET_ID_COMMENT(NEW_VALUE NUMBER, OLD_VALUE NUMBER);
END PKG_ADMIN_PERSON_X_COMMENT;


CREATE OR REPLACE PACKAGE BODY PKG_ADMIN_PERSON_X_COMMENT IS
        --FUNCTION GET_ID_PERSON IMPLEMENTATION
/*        FUNCTION GET_ID_PERSON(PNID_COMMENT IN NUMBER)  RETURN VARCHAR2
         IS
                  VMENERROR      EXCEPTION;
                  VNID_PERSON   VARCHAR2(30);
         BEGIN
                  SELECT ID_PERSON
                  INTO VNID_PERSON
                  FROM PERSON_X_COMMENT
                  WHERE ID_COMMENT=PNID_COMMENT;
                  RETURN (VNID_PERSON);
                  EXCEPTION 
                         WHEN TOO_MANY_ROWS THEN
                           DBMS_OUTPUT.PUT_LINE('YOUR SELECTION RETURNS MORE THAN ONE RESULT.');
                         WHEN NO_DATA_FOUND THEN
                           DBMS_OUTPUT.PUT_LINE('THE ELEMENT DOES NOT EXIST IN THE DATABASE.');
                         WHEN OTHERS THEN
                           DBMS_OUTPUT.PUT_LINE('ERROR');
         END;*/

        -------------------------------------------------------------------------------
        --FUNCTION GET_ID_COMMENT IMPLEMENTATION
        --FUNCTION GET_ID_COMMENT(PNID_PERSON IN NUMBER) RETURN NUMBER
        --IS
        --         VNID_COMMENT NUMBER(20);

        --BEGIN
        --          SELECT ID_COMMENT
        --          INTO VNID_COMMENT
        --          FROM PERSON_X_COMMENT
        --          WHERE ID_PERSON=PNID_PERSON;
        --          RETURN (VNID_COMMENT);
        --END;

        PROCEDURE INSERT_PERSON_X_COMMENT(PNID_PERSON VARCHAR2,PNID_COMMENT NUMBER) IS
      VMENERROR                                     EXCEPTION;

           BEGIN
             INSERT INTO PERSON_X_COMMENT(ID_PERSON, ID_COMMENT)
             VALUES (PNID_PERSON, PNID_COMMENT);
             IF SQL%NOTFOUND THEN
                    RAISE VMENERROR;
            END IF;
            EXCEPTION 
               WHEN VMENERROR THEN
                 DBMS_OUTPUT.PUT_LINE('THE ELEMENT DOES NOT EXIST IN THE DATABASE.');
               WHEN DUP_VAL_ON_INDEX THEN
                 DBMS_OUTPUT.PUT_LINE('THE ELEMENT IS ALREADY IN THE DATABASE.');

           END INSERT_PERSON_X_COMMENT;


           ---------------------------------------------------------------------------------
    --PROCEDURE SET_ID_PERSON(NEW_VALUE NUMBER, OLD_VALUE NUMBER) IS
    --     BEGIN
    --         UPDATE PERSON_X_COMMENT SET ID_PERSON= NEW_VALUE WHERE ID_PERSON=OLD_VALUE;
    --     END SET_ID_PERSON;


         ---------------------------------------------------------------------------------
    --PROCEDURE SET_ID_COMMENT(NEW_VALUE NUMBER, OLD_VALUE NUMBER) IS
    --     BEGIN
    --         UPDATE PERSON_X_COMMENT SET ID_COMMENT= NEW_VALUE WHERE ID_COMMENT=OLD_VALUE;
    --     END SET_ID_COMMENT;
END PKG_ADMIN_PERSON_X_COMMENT;
