/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frames;

import Business.Funciones;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author kenneth
 */
public class proposalVisualizer extends javax.swing.JFrame {

    /**
     * Creates new form proposalVisualizer
     */
    public proposalVisualizer(int ptypeUser,String pCedula,String[] arreglo,int pComunidad) throws SQLException {
        initComponents();
       txtDescripcion.setEditable(false);  
        this.typeUser=ptypeUser;
        this.cedula=pCedula;
        this.arreglo=arreglo;
        this.comunidad=pComunidad;
        this.idProposal=arreglo[0];
        /*this.titulo=pTitulo;
        this.descripcion=pDescripcion;
        this.budget=pBudget;
        this.votes=pVotes;
        this.proposalDate=pProposalDate;
        this.categories=pCategories;*/
        Funciones business=new Funciones();
        ResultSet r1=business.getAllInfoProposal(Integer.parseInt(arreglo[0]));
        r1.next();       
        
        this.txtTitulo.setText(arreglo[1]);
        this.txtDescripcion.setText(arreglo[2]);
        
        this.lblCategoria.setText(r1.getString("CATEGORY_NAME"));        
        this.lblPresupuesto.setText(r1.getString("BUDGET"));
        this.lblVotos.setText(r1.getString("VOTE"));
        this.lblExpositor.setText(r1.getString("NAME")+" "+r1.getString("FIRST_LAST_NAME")+" "+r1.getString("SECOND_LAST_NAME"));
        this.lblCorreo.setText(r1.getString("EMAIL"));
        this.lblTelefono.setText(r1.getString("TELEPHONE"));

        Funciones utils = new Funciones();
         ResultSet r=utils.obtenerComentarios(arreglo[0]);
            
         int posY=30;
         while(r.next()){
           String[] arregloComentario={r.getString("ID_COMMENT"),r.getString("COMMENT_DESCRIPTION"),r.getString("COMMENT_DATE"),r.getString("NAME")};
           crearComentarios(posY,arregloComentario);
           posY+=170;
         }
    }
    
    public static int typeUser;
    public static String cedula;
    public static int comunidad;
    public static String titulo;
    public static String descripcion;
    public static String budget;
    public static String votes;
    public static String proposalDate;
   public static String categories;
   public static String idProposal;
   public static String[] arreglo;

   
    
    public proposalVisualizer(String titulo){
        initComponents();
    }
    
    
    
    
    
    
    private void crearComentarios(int posY,String[] arreglo) {
        System.out.println("Arreglo "+arreglo[0]);
        javax.swing.JLabel txtMainTitle;
        javax.swing.JPanel panelproposal;
        javax.swing.JTextArea areaTexto;
        javax.swing.JScrollPane panelScroll;
        javax.swing.JLabel txtHora;
        

        //se inicializan los objetos
        panelproposal = new javax.swing.JPanel();
        areaTexto = new javax.swing.JTextArea();
        panelScroll = new javax.swing.JScrollPane();
        txtMainTitle = new javax.swing.JLabel();
        txtHora = new javax.swing.JLabel();

        //se le modifican atributos al panel principal de los comentarios
        panelproposal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelproposal.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 51, 255)));

        //creo el nombre del due;o y lo inserto en el panel 
        txtMainTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtMainTitle.setText(arreglo[3]);
        panelproposal.add(txtMainTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 50));
        
        //creo un txt que contiene la hora en la que fue creado el comentario
        txtHora.setFont(new java.awt.Font("Segoe UI", 0, 14));
        txtHora.setText(arreglo[2]);
        panelproposal.add(txtHora,new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 0, -1, 50));
        
        //creo e inserto la caja de texto
        areaTexto.setColumns(20);
        areaTexto.setRows(5);
        panelScroll.setViewportView(areaTexto);
        panelScroll.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panelproposal.add(panelScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 48, 740, 105));
        areaTexto.setLineWrap(true);
        areaTexto.setFont(new java.awt.Font("Segoe UI", 1, 14)); 
        areaTexto.setText(arreglo[1]);
        panelComment.add(panelproposal, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, posY, 800, 160));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel3 = new keeptoo.KGradientPanel();
        mainPanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        panelComment = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtTitulo = new javax.swing.JLabel();
        lblPresupuesto = new javax.swing.JLabel();
        lblExpositor = new javax.swing.JLabel();
        lblCorreo = new javax.swing.JLabel();
        lblCategoria = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblVotos = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lblTelefono = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        btnHome = new javax.swing.JLabel();
        btnNewComment = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 204));
        jLabel3.setText("Presupuesto:");
        mainPanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 110, 40));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 204));
        jLabel4.setText("Comentarios acerca de la propuesta:");
        mainPanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 300, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 204));
        jLabel10.setText("Categoria:");
        mainPanel.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 80, 30));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        txtDescripcion.setColumns(20);
        txtDescripcion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setRows(5);
        txtDescripcion.setWrapStyleWord(true);
        jScrollPane1.setViewportView(txtDescripcion);

        mainPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 710, 50));

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        panelComment.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jScrollPane2.setViewportView(panelComment);

        mainPanel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 710, 230));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 204));
        jLabel11.setText("Correo Contacto:");
        mainPanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 110, 150, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 0, 204));
        jLabel12.setText("Expositor:");
        mainPanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 80, 30));

        txtTitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtTitulo.setForeground(new java.awt.Color(255, 0, 204));
        txtTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTitulo.setText("Titulo de la propuesta:");
        mainPanel.add(txtTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 380, 40));

        lblPresupuesto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mainPanel.add(lblPresupuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 230, 20));

        lblExpositor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mainPanel.add(lblExpositor, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 70, 100, 30));

        lblCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mainPanel.add(lblCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 110, 290, 30));

        lblCategoria.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mainPanel.add(lblCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 150, 20));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 204));
        jLabel7.setText("Votos:");
        mainPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 80, 40));

        lblVotos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mainPanel.add(lblVotos, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 110, 20));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 0, 204));
        jLabel14.setText("Telefono:");
        mainPanel.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 150, 80, 30));

        lblTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mainPanel.add(lblTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, 290, 30));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/cancel36px.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        mainPanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 20, -1, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 204));
        jLabel8.setText("Descripción:");
        mainPanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 110, 30));

        mainPanel.setBackground(new Color(0,0,0,80));

        kGradientPanel3.add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 760, 580));

        getContentPane().add(kGradientPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 780, 800));

        kGradientPanel1.setkEndColor(new java.awt.Color(51, 0, 204));
        kGradientPanel1.setkStartColor(new java.awt.Color(204, 0, 204));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/home.png"))); // NOI18N
        btnHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHomeMouseClicked(evt);
            }
        });
        kGradientPanel1.add(btnHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        btnNewComment.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/134945_opt.png"))); // NOI18N
        btnNewComment.setText("jLabel8");
        btnNewComment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnNewCommentMouseClicked(evt);
            }
        });
        kGradientPanel1.add(btnNewComment, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 60, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Botar por esta propuesta");
        kGradientPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 190, 40));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Menú Principal");
        kGradientPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 110, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/thumbUp.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        kGradientPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, -1, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Agregar un comentario");
        kGradientPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 170, 40));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 610));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void btnHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseClicked
        try {
            // TODO add your handling code here:
            mainWindow ventana =new mainWindow(typeUser,cedula,comunidad);
            ventana.setVisible(true);
            this.dispose();
        } catch (SQLException ex) {
            Logger.getLogger(proposalVisualizer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnHomeMouseClicked

    private void btnNewCommentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnNewCommentMouseClicked
            newComment ventana =new newComment(typeUser,cedula,idProposal,comunidad);
            ventana.setVisible(true);
            this.dispose();
    }//GEN-LAST:event_btnNewCommentMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        try {
            Funciones business=new Funciones();
            business.registerVote(cedula,Integer.parseInt(idProposal));
            javax.swing.JOptionPane.showMessageDialog(null, "Se ha registrado correctamente su voto en esta propuesta, muchas gracias!!");
            jLabel1.setVisible(false);
            jLabel9.setVisible(false);
        } catch (SQLException ex) {
            Logger.getLogger(proposalVisualizer.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }//GEN-LAST:event_jLabel1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(proposalVisualizer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(proposalVisualizer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(proposalVisualizer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(proposalVisualizer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new proposalVisualizer( typeUser,cedula, arreglo,comunidad).setVisible(true);
                } catch (SQLException ex) {
                    System.out.println("Problemas en la excepcion de la ventana proposalVisualizer");
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnHome;
    private javax.swing.JLabel btnNewComment;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel3;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblExpositor;
    private javax.swing.JLabel lblPresupuesto;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JLabel lblVotos;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel panelComment;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JLabel txtTitulo;
    // End of variables declaration//GEN-END:variables
}
